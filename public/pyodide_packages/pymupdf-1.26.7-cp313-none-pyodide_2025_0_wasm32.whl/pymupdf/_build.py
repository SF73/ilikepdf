mupdf_location = 'https://mupdf.com/downloads/archive/mupdf-1.26.12-source.tar.gz'
pymupdf_version = '1.26.7'
pymupdf_version_tuple = (1, 26, 7)
pymupdf_git_sha = '525bb0a48f52e18a560dda8c412ed2d51e0f064e'
pymupdf_git_diff = ''
pymupdf_git_branch = 'main'
swig_version = '4.3.1'
swig_version_tuple = (4, 3, 1)
